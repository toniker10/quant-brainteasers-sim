"""Unit tests for src/coupon_collector.py"""

import os
import sys
from fractions import Fraction

import numpy as np
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.coupon_collector import CouponCollectorAnalytics, CouponCollectorSimulator


class TestAnalytics:
    def test_small_cases(self):
        assert CouponCollectorAnalytics(1).expected_draws() == 1
        assert CouponCollectorAnalytics(2).expected_draws() == 3
        assert CouponCollectorAnalytics(6).expected_draws() == Fraction(147, 10)

    def test_cdf_two_coupons(self):
        # P(T <= t) = 1 - 2 * (1/2)^t for n = 2
        a = CouponCollectorAnalytics(2)
        for t in range(2, 8):
            assert a.cdf(t) == 1 - Fraction(2, 2**t)

    def test_cdf_below_n_is_zero_and_increasing(self):
        a = CouponCollectorAnalytics(5)
        assert a.cdf(4) == 0
        vals = [a.cdf(t) for t in range(5, 40)]
        assert all(x < y for x, y in zip(vals, vals[1:]))

    def test_mean_from_cdf(self):
        a = CouponCollectorAnalytics(4)
        mean = sum(a.tail_probability(t) for t in range(0, 400))
        assert float(mean) == pytest.approx(float(a.expected_draws()), abs=1e-6)

    def test_asymptotic_close_for_large_n(self):
        a = CouponCollectorAnalytics(1000)
        assert a.asymptotic_expected_draws() == pytest.approx(float(a.expected_draws()), abs=0.01)


class TestSimulator:
    def test_mean_and_variance_match(self):
        a = CouponCollectorAnalytics(20)
        r = CouponCollectorSimulator(20, seed=5).run(40_000)
        assert r.mean == pytest.approx(float(a.expected_draws()), abs=5 * r.std_error_of_mean)
        assert r.variance == pytest.approx(float(a.variance()), rel=0.05)

    def test_empirical_cdf_matches(self):
        a = CouponCollectorAnalytics(10)
        r = CouponCollectorSimulator(10, seed=9).run(40_000)
        assert r.empirical_cdf(40) == pytest.approx(float(a.cdf(40)), abs=0.01)

    def test_minimum_draws_is_n(self):
        r = CouponCollectorSimulator(8, seed=1).run(5_000)
        assert r.samples.min() >= 8
