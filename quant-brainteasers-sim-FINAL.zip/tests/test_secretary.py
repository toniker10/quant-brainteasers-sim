"""Unit tests for src/secretary_problem.py"""

import os
import sys
from fractions import Fraction

import numpy as np
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.secretary_problem import SecretaryAnalytics, SecretarySimulator


class TestAnalytics:
    def test_known_small_cases(self):
        # n = 3: best policy rejects 1, success probability 1/2
        a = SecretaryAnalytics(3)
        assert a.optimal_cutoff() == 1
        assert a.optimal_probability() == Fraction(1, 2)
        # n = 4: 11/24 with k = 1
        assert SecretaryAnalytics(4).success_probability(1) == Fraction(11, 24)

    def test_n100_classic_values(self):
        a = SecretaryAnalytics(100)
        assert a.optimal_cutoff() == 37
        assert float(a.optimal_probability()) == pytest.approx(0.3710, abs=1e-4)

    def test_converges_to_one_over_e(self):
        a = SecretaryAnalytics(2000)
        assert float(a.optimal_probability()) == pytest.approx(1 / np.e, abs=1e-3)
        assert a.optimal_cutoff() == pytest.approx(2000 / np.e, abs=2)

    def test_k0_is_one_over_n(self):
        assert SecretaryAnalytics(10).success_probability(0) == Fraction(1, 10)

    def test_invalid_k(self):
        with pytest.raises(ValueError):
            SecretaryAnalytics(5).success_probability(5)


class TestSimulator:
    @pytest.mark.parametrize("k", [0, 5, 14, 30])
    def test_monte_carlo_matches_exact(self, k):
        n = 40
        exact = float(SecretaryAnalytics(n).success_probability(k))
        r = SecretarySimulator(n, seed=3).run(k, num_trials=80_000)
        assert r.success_rate == pytest.approx(exact, abs=5 * r.std_error)
