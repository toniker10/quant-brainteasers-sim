"""Unit tests for src/gamblers_ruin.py"""

import os
import sys
from fractions import Fraction

import numpy as np
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.gamblers_ruin import GamblersRuinAnalytics, GamblersRuinSimulator


class TestAnalytics:
    def test_fair_win_probability_is_linear(self):
        assert GamblersRuinAnalytics(10, 20).win_probability() == Fraction(1, 2)
        assert GamblersRuinAnalytics(3, 12).win_probability() == Fraction(1, 4)

    def test_fair_expected_duration(self):
        assert GamblersRuinAnalytics(10, 20).expected_duration() == 100

    def test_win_plus_ruin_is_one(self):
        a = GamblersRuinAnalytics(7, 25, Fraction(11, 20))
        assert a.win_probability() + a.ruin_probability() == 1

    def test_positive_edge_improves_win_probability(self):
        assert GamblersRuinAnalytics(10, 20, 0.55).win_probability() > Fraction(1, 2)

    def test_boundary_states(self):
        assert GamblersRuinAnalytics(0, 10, 0.6).win_probability() == 0
        assert GamblersRuinAnalytics(10, 10, 0.6).win_probability() == 1

    def test_infinite_casino(self):
        assert GamblersRuinAnalytics(5, 50).ruin_probability_infinite_casino() == 1
        assert GamblersRuinAnalytics(5, 50, 0.4).ruin_probability_infinite_casino() == 1
        a = GamblersRuinAnalytics(3, 50, Fraction(2, 3))
        assert a.ruin_probability_infinite_casino() == Fraction(1, 8)

    def test_duration_satisfies_recurrence(self):
        p = Fraction(3, 5)
        N = 12
        E = [GamblersRuinAnalytics(i, N, p).expected_duration() for i in range(N + 1)]
        for i in range(1, N):
            assert E[i] == 1 + p * E[i + 1] + (1 - p) * E[i - 1]

    @pytest.mark.parametrize("bad", [(-1, 5, 0.5), (6, 5, 0.5), (1, 5, 0.0), (1, 5, 1.0)])
    def test_invalid_inputs(self, bad):
        with pytest.raises(ValueError):
            GamblersRuinAnalytics(*bad)


class TestSimulator:
    @pytest.mark.parametrize("p", [0.5, 0.55])
    def test_monte_carlo_matches_analytics(self, p):
        a = GamblersRuinAnalytics(10, 20, p)
        r = GamblersRuinSimulator(10, 20, p, seed=1).run(60_000)
        assert r.win_rate == pytest.approx(float(a.win_probability()), abs=5 * r.win_std_error)
        assert r.mean_duration == pytest.approx(float(a.expected_duration()), rel=0.03)

    def test_reproducible(self):
        a = GamblersRuinSimulator(5, 10, seed=7).run(2_000)
        b = GamblersRuinSimulator(5, 10, seed=7).run(2_000)
        assert a.win_rate == b.win_rate
