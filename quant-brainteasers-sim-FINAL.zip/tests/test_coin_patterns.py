"""Unit tests for src/coin_patterns.py"""

import os
import sys
from fractions import Fraction

import numpy as np
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.coin_patterns import (
    CoinPatternSimulator,
    PenneyAnalytics,
    correlation,
    expected_waiting_time,
)


class TestWaitingTimes:
    @pytest.mark.parametrize("pat,expected", [("HH", 6), ("HT", 4), ("HTH", 10), ("HHH", 14), ("HHT", 8)])
    def test_known_values(self, pat, expected):
        assert expected_waiting_time(pat) == expected

    def test_matches_dice_problem(self):
        assert expected_waiting_time([3, 4, 5], alphabet_size=6) == 6**3
        assert expected_waiting_time([6, 6], alphabet_size=6) == 6**2 + 6

    def test_correlation_basic(self):
        assert correlation("HHH", "HHH") == 7
        assert correlation("HHH", "THH") == 0
        assert correlation("THH", "HHH") == 3

    @pytest.mark.parametrize("pat", ["HH", "HT", "HTH"])
    def test_simulation_matches(self, pat):
        r = CoinPatternSimulator(seed=2).waiting_time(pat, num_trials=60_000)
        assert r.mean_waiting_time == pytest.approx(expected_waiting_time(pat), abs=5 * r.std_error)


class TestPenney:
    def test_classic_hhh_vs_thh(self):
        assert PenneyAnalytics.prob_b_first("HHH", "THH") == Fraction(7, 8)

    def test_probabilities_are_complementary(self):
        p = PenneyAnalytics.prob_b_first("HTH", "HHT")
        q = PenneyAnalytics.prob_b_first("HHT", "HTH")
        assert p + q == 1

    def test_non_transitivity(self):
        # HHT > HTT? ; HTT > TTH ; TTH > THH ; THH > HHT  (cycle)
        beats = lambda a, b: PenneyAnalytics.prob_b_first(b, a) > Fraction(1, 2)  # a beats b
        assert beats("HHT", "HTT") and beats("HTT", "TTH") and beats("TTH", "THH") and beats("THH", "HHT")

    def test_second_player_always_has_advantage(self):
        from itertools import product

        for tup in product("HT", repeat=3):
            a = "".join(tup)
            b = PenneyAnalytics.best_response(a)
            assert PenneyAnalytics.prob_b_first(a, b) > Fraction(1, 2)

    def test_best_response_to_htt(self):
        assert PenneyAnalytics.best_response("HTT") == "HHT"
        assert PenneyAnalytics.prob_b_first("HTT", "HHT") == Fraction(2, 3)

    def test_simulation_matches_exact(self):
        exact = float(PenneyAnalytics.prob_b_first("HHT", "HTH"))
        r = CoinPatternSimulator(seed=4).penney("HHT", "HTH", num_trials=80_000)
        assert r.b_win_rate == pytest.approx(exact, abs=5 * r.std_error)

    def test_invalid_patterns(self):
        with pytest.raises(ValueError):
            PenneyAnalytics.prob_b_first("HH", "HH")
        with pytest.raises(ValueError):
            PenneyAnalytics.prob_b_first("HH", "HHT")  # contained pattern
        with pytest.raises(ValueError):
            expected_waiting_time("")
