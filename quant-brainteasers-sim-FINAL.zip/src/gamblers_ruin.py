"""
gamblers_ruin.py
=================

Module 3: The Gambler's Ruin.

Problem
-------
A gambler starts with ``i`` dollars and repeatedly bets $1 on a coin that
wins with probability ``p`` (loses with ``q = 1 - p``). The game stops when
the gambler reaches ``N`` dollars (success) or $0 (ruin).

  * What is the probability of reaching ``N`` before going broke?
  * What is the expected number of bets until the game ends?
  * What if the casino has infinite wealth (``N -> infinity``)?

Exact solution
--------------
Let ``r = q / p``. Conditioning on the first bet gives a linear recurrence
whose solution is:

    fair coin (p = 1/2):
        P(win)  = i / N
        E[T]    = i * (N - i)

    biased coin (p != 1/2):
        P(win)  = (1 - r^i) / (1 - r^N)
        E[T]    = i / (q - p)  -  (N / (q - p)) * (1 - r^i) / (1 - r^N)

    N -> infinity:
        P(ruin) = 1            if p <= 1/2
        P(ruin) = (q/p)^i      if p >  1/2

Quant relevance: even with a *positive-edge* bet (p > 1/2), a finite
bankroll has a non-trivial probability of ruin -- the reason position
sizing and risk limits matter more than the edge itself.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, Union

import numpy as np

Number = Union[int, float, Fraction]


def _as_fraction(p: Number) -> Fraction:
    """Convert ``p`` to an exact Fraction (floats are rationalised)."""
    if isinstance(p, Fraction):
        return p
    if isinstance(p, int):
        return Fraction(p)
    return Fraction(p).limit_denominator(10**9)


class GamblersRuinAnalytics:
    """Closed-form results for the gambler's ruin problem (exact Fractions)."""

    def __init__(self, start: int, target: int, p: Number = Fraction(1, 2)):
        if not (0 <= start <= target) or target <= 0:
            raise ValueError("need 0 <= start <= target and target > 0")
        p = _as_fraction(p)
        if not (0 < p < 1):
            raise ValueError("p must be strictly between 0 and 1")
        self.start = int(start)
        self.target = int(target)
        self.p = p
        self.q = 1 - p

    @property
    def is_fair(self) -> bool:
        return self.p == Fraction(1, 2)

    def win_probability(self) -> Fraction:
        i, N = self.start, self.target
        if self.is_fair:
            return Fraction(i, N)
        r = self.q / self.p
        return (1 - r**i) / (1 - r**N)

    def ruin_probability(self) -> Fraction:
        return 1 - self.win_probability()

    def expected_duration(self) -> Fraction:
        i, N = self.start, self.target
        if self.is_fair:
            return Fraction(i * (N - i))
        r = self.q / self.p
        diff = self.q - self.p
        return Fraction(i) / diff - (Fraction(N) / diff) * (1 - r**i) / (1 - r**N)

    def ruin_probability_infinite_casino(self) -> Fraction:
        """P(ever hitting 0) against an opponent with unlimited wealth."""
        if self.p <= Fraction(1, 2):
            return Fraction(1)
        return (self.q / self.p) ** self.start

    def summary(self) -> Dict[str, float]:
        return {
            "start": self.start,
            "target": self.target,
            "p": float(self.p),
            "P(win)": float(self.win_probability()),
            "P(ruin)": float(self.ruin_probability()),
            "E[duration]": float(self.expected_duration()),
            "P(ruin | infinite casino)": float(self.ruin_probability_infinite_casino()),
        }


@dataclass
class RuinSimulationResult:
    num_trials: int
    win_rate: float
    ruin_rate: float
    mean_duration: float
    win_std_error: float

    def summary(self) -> Dict[str, float]:
        return {
            "num_trials": self.num_trials,
            "empirical P(win)": self.win_rate,
            "empirical P(ruin)": self.ruin_rate,
            "empirical E[duration]": self.mean_duration,
            "std error (P(win))": self.win_std_error,
        }


class GamblersRuinSimulator:
    """Vectorised Monte Carlo simulation of many independent gamblers."""

    def __init__(self, start: int, target: int, p: float = 0.5, seed: int = 42):
        self.start, self.target, self.p = int(start), int(target), float(p)
        self.rng = np.random.default_rng(seed)

    def run(self, num_trials: int = 100_000, max_steps: int = 10_000_000) -> RuinSimulationResult:
        wealth = np.full(num_trials, self.start, dtype=np.int64)
        steps = np.zeros(num_trials, dtype=np.int64)
        active = (wealth > 0) & (wealth < self.target)
        t = 0
        while active.any():
            t += 1
            if t > max_steps:
                raise RuntimeError("max_steps exceeded")
            idx = np.flatnonzero(active)
            moves = np.where(self.rng.random(idx.size) < self.p, 1, -1)
            wealth[idx] += moves
            steps[idx] += 1
            active[idx] = (wealth[idx] > 0) & (wealth[idx] < self.target)
        wins = wealth >= self.target
        win_rate = float(wins.mean())
        return RuinSimulationResult(
            num_trials=num_trials,
            win_rate=win_rate,
            ruin_rate=1.0 - win_rate,
            mean_duration=float(steps.mean()),
            win_std_error=float(np.sqrt(win_rate * (1 - win_rate) / num_trials)),
        )
