"""
quant-brainteasers-sim
=======================

A collection of quant-interview brainteaser simulations:

- ``betting_game``: The coin betting dilemma (EV maximization vs. Kelly
  Criterion vs. fixed-fraction betting, ergodicity, and risk of ruin).
- ``dice_sequence``: The [3, 4, 5] dice sequence problem (absorbing Markov
  chains, exact linear-algebra solutions, and a generalized KMP-based
  solver for arbitrary target sequences).
- ``gamblers_ruin``: Ruin probability and expected duration of a random walk.
- ``secretary_problem``: Optimal stopping and the 1/e rule.
- ``coupon_collector``: Collection-time mean, variance and exact distribution.
- ``coin_patterns``: Pattern waiting times and Penney's game (Conway's formula).
"""

from . import (
    betting_game,
    coin_patterns,
    coupon_collector,
    dice_sequence,
    gamblers_ruin,
    secretary_problem,
)

__all__ = [
    "betting_game",
    "dice_sequence",
    "gamblers_ruin",
    "secretary_problem",
    "coupon_collector",
    "coin_patterns",
]

__version__ = "1.1.0"
