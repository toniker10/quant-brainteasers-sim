"""
coupon_collector.py
====================

Module 5: The Coupon Collector.

Problem
-------
There are ``n`` equally likely coupon types. You draw one at random (with
replacement) each round. How many draws ``T`` until you have collected all
``n`` types?

Exact solution
--------------
``T`` is a sum of independent geometric waiting times (the time to find the
(m+1)-th new type has success probability ``(n - m) / n``):

    E[T]   = n * H_n                      (H_n = harmonic number)
    Var[T] = n^2 * sum_{i=1}^{n} 1/i^2  -  n * H_n
    E[T]  ~ n ln n + gamma * n + 1/2      (gamma = Euler-Mascheroni)

and the full distribution follows from inclusion-exclusion:

    P(T <= t) = sum_{j=0}^{n} (-1)^j * C(n, j) * (1 - j/n)^t

Quant relevance: covering/sampling problems (how many random samples to
touch every bucket), hash-table load, and the fact that the *tail* is
heavy -- you typically need ~ n ln n draws, but with real probability you
need noticeably more.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from fractions import Fraction
from typing import Dict

import numpy as np

EULER_GAMMA = 0.5772156649015329


class CouponCollectorAnalytics:
    """Exact results for the coupon collector problem."""

    def __init__(self, n: int):
        if n < 1:
            raise ValueError("n must be >= 1")
        self.n = int(n)

    def expected_draws(self) -> Fraction:
        return self.n * sum(Fraction(1, i) for i in range(1, self.n + 1))

    def variance(self) -> Fraction:
        n = self.n
        h2 = sum(Fraction(1, i * i) for i in range(1, n + 1))
        return n * n * h2 - self.expected_draws()

    def asymptotic_expected_draws(self) -> float:
        n = self.n
        return n * math.log(n) + EULER_GAMMA * n + 0.5

    def cdf(self, t: int) -> Fraction:
        """P(T <= t) via inclusion-exclusion (exact)."""
        n = self.n
        if t < n:
            return Fraction(0)
        return sum(
            (-1) ** j * math.comb(n, j) * Fraction(n - j, n) ** t for j in range(n + 1)
        )

    def tail_probability(self, t: int) -> Fraction:
        return 1 - self.cdf(t)

    def summary(self) -> Dict[str, float]:
        return {
            "n": self.n,
            "E[T]": float(self.expected_draws()),
            "Var[T]": float(self.variance()),
            "Std[T]": math.sqrt(float(self.variance())),
            "asymptotic E[T]": self.asymptotic_expected_draws(),
        }


@dataclass
class CouponSimulationResult:
    n: int
    num_trials: int
    mean: float
    variance: float
    std_error_of_mean: float
    samples: np.ndarray

    def empirical_cdf(self, t: int) -> float:
        return float((self.samples <= t).mean())


class CouponCollectorSimulator:
    """Vectorised Monte Carlo: advance all unfinished trials one draw at a time."""

    def __init__(self, n: int, seed: int = 42):
        self.n = int(n)
        self.rng = np.random.default_rng(seed)

    def run(self, num_trials: int = 50_000) -> CouponSimulationResult:
        n = self.n
        seen = np.zeros((num_trials, n), dtype=bool)
        counts = np.zeros(num_trials, dtype=np.int64)
        draws = np.zeros(num_trials, dtype=np.int64)
        active = np.arange(num_trials)
        while active.size:
            coupons = self.rng.integers(0, n, size=active.size)
            draws[active] += 1
            fresh = ~seen[active, coupons]
            seen[active, coupons] = True
            counts[active] += fresh
            active = active[counts[active] < n]
        return CouponSimulationResult(
            n=n, num_trials=num_trials,
            mean=float(draws.mean()), variance=float(draws.var(ddof=1)),
            std_error_of_mean=float(draws.std(ddof=1) / math.sqrt(num_trials)),
            samples=draws,
        )
