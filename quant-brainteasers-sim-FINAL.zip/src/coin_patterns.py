"""
coin_patterns.py
=================

Module 6: Coin-Flip Patterns and Penney's Game.

Problems
--------
1. How many fair-coin flips, on average, until the pattern ``HH`` first
   appears? What about ``HT``? (Answers: 6 and 4 -- not equal!)
2. Penney's game: you pick a pattern, your opponent then picks another.
   A coin is flipped until one of the patterns appears; its owner wins.
   The game is *non-transitive* -- for any pattern you choose, the second
   player can pick one that beats it.

Exact solution (Conway's leading-number algorithm)
--------------------------------------------------
For patterns ``X`` and ``Y`` over an alphabet of size ``m`` define the
correlation

    X.Y = sum_{k=1}^{L} [suffix_k(X) == prefix_k(Y)] * m^(k-1)

Then:

    E[waiting time for A]   = m * (A.A)          (i.e. sum of m^k over self-overlaps)
    Odds(B beats A)         = (A.A - A.B) : (B.B - B.A)      (fair coin, m = 2)

The same self-overlap structure is exactly why the [3,4,5] dice problem
(no overlap -> E = 6^3) differs from [6,6] (overlap -> E = 6^2 + 6).
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Dict

import numpy as np


def _validate(pattern: str) -> str:
    pattern = pattern.upper()
    if not pattern or set(pattern) - {"H", "T"}:
        raise ValueError("pattern must be a non-empty string over {H, T}")
    return pattern


def correlation(x: str, y: str, alphabet_size: int = 2) -> int:
    """Conway correlation X.Y = sum over k with suffix_k(X)==prefix_k(Y) of m^(k-1)."""
    total = 0
    for k in range(1, min(len(x), len(y)) + 1):
        if x[-k:] == y[:k]:
            total += alphabet_size ** (k - 1)
    return total


def expected_waiting_time(pattern, alphabet_size: int = 2) -> int:
    """E[number of i.i.d. uniform symbols until ``pattern`` first appears].

    ``pattern`` can be any sequence (string or list); symbols are compared
    for equality only.
    """
    seq = list(pattern)
    if not seq:
        raise ValueError("pattern must be non-empty")
    total = 0
    for k in range(1, len(seq) + 1):
        if seq[:k] == seq[-k:]:
            total += alphabet_size**k
    return total


class PenneyAnalytics:
    """Exact head-to-head probabilities via Conway's formula."""

    @staticmethod
    def prob_b_first(a: str, b: str) -> Fraction:
        """P(pattern ``b`` appears before pattern ``a``), fair coin."""
        a, b = _validate(a), _validate(b)
        if a == b:
            raise ValueError("patterns must differ")
        if a in b or b in a:
            raise ValueError("neither pattern may be contained in the other")
        num = correlation(a, a) - correlation(a, b)
        den = num + correlation(b, b) - correlation(b, a)
        return Fraction(num, den)

    @staticmethod
    def best_response(a: str) -> str:
        """Pattern of the same length that maximises P(beats ``a``)."""
        a = _validate(a)
        from itertools import product

        best, best_p = None, Fraction(-1)
        for tup in product("HT", repeat=len(a)):
            b = "".join(tup)
            if b == a:
                continue
            try:
                p = PenneyAnalytics.prob_b_first(a, b)
            except ValueError:
                continue
            if p > best_p:
                best, best_p = b, p
        return best

    @staticmethod
    def summary(a: str, b: str) -> Dict[str, object]:
        p = PenneyAnalytics.prob_b_first(a, b)
        return {"A": a, "B": b, "P(B first)": float(p), "P(A first)": float(1 - p)}


@dataclass
class PatternSimulationResult:
    mean_waiting_time: float
    std_error: float
    num_trials: int


@dataclass
class PenneySimulationResult:
    b_win_rate: float
    std_error: float
    num_trials: int


class CoinPatternSimulator:
    """Vectorised simulation using a rolling bit-window over the flip stream."""

    def __init__(self, seed: int = 42):
        self.rng = np.random.default_rng(seed)

    @staticmethod
    def _to_bits(pattern: str) -> int:
        return int("".join("1" if c == "H" else "0" for c in pattern), 2)

    def waiting_time(self, pattern: str, num_trials: int = 100_000) -> PatternSimulationResult:
        pattern = _validate(pattern)
        L = len(pattern)
        target, mask = self._to_bits(pattern), (1 << L) - 1
        window = np.zeros(num_trials, dtype=np.int64)
        flips = np.zeros(num_trials, dtype=np.int64)
        active = np.arange(num_trials)
        while active.size:
            bits = self.rng.integers(0, 2, size=active.size)
            window[active] = ((window[active] << 1) | bits) & mask
            flips[active] += 1
            done = (flips[active] >= L) & (window[active] == target)
            active = active[~done]
        return PatternSimulationResult(
            mean_waiting_time=float(flips.mean()),
            std_error=float(flips.std(ddof=1) / np.sqrt(num_trials)),
            num_trials=num_trials,
        )

    def penney(self, a: str, b: str, num_trials: int = 100_000) -> PenneySimulationResult:
        a, b = _validate(a), _validate(b)
        La, Lb = len(a), len(b)
        ta, tb = self._to_bits(a), self._to_bits(b)
        ma, mb = (1 << La) - 1, (1 << Lb) - 1
        width = (1 << max(La, Lb)) - 1
        window = np.zeros(num_trials, dtype=np.int64)
        flips = np.zeros(num_trials, dtype=np.int64)
        b_won = np.zeros(num_trials, dtype=bool)
        active = np.arange(num_trials)
        while active.size:
            bits = self.rng.integers(0, 2, size=active.size)
            window[active] = ((window[active] << 1) | bits) & width
            flips[active] += 1
            w, f = window[active], flips[active]
            hit_a = (f >= La) & ((w & ma) == ta)
            hit_b = (f >= Lb) & ((w & mb) == tb)
            b_won[active[hit_b & ~hit_a]] = True
            active = active[~(hit_a | hit_b)]
        rate = float(b_won.mean())
        return PenneySimulationResult(
            b_win_rate=rate, std_error=float(np.sqrt(rate * (1 - rate) / num_trials)),
            num_trials=num_trials,
        )
