"""
secretary_problem.py
=====================

Module 4: The Secretary Problem (optimal stopping).

Problem
-------
``n`` candidates arrive in uniformly random order. After each interview you
must immediately accept or reject, and you can only compare against
candidates already seen. How do you maximise the probability of hiring the
single *best* candidate?

Optimal policy (threshold rule)
-------------------------------
Reject the first ``k`` candidates, then accept the first candidate who is
better than everyone seen so far.

Exact success probability, for ``k >= 1``:

    P(k, n) = (k / n) * sum_{j = k+1}^{n} 1 / (j - 1)

(and ``P(0, n) = 1 / n``). For large ``n`` the optimal cutoff is
``k* ~ n / e`` and the success probability tends to ``1 / e ~ 0.3679``.

Quant relevance: the same structure appears in "when to exercise" problems
(American options), execution timing, and any irreversible decision made
under sequential information.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, List

import numpy as np


class SecretaryAnalytics:
    """Exact results for the classical secretary problem."""

    def __init__(self, n: int):
        if n < 1:
            raise ValueError("n must be >= 1")
        self.n = int(n)

    def success_probability(self, k: int) -> Fraction:
        """P(hire the best) when rejecting the first ``k`` candidates."""
        n = self.n
        if not (0 <= k < n):
            raise ValueError("need 0 <= k < n")
        if k == 0:
            return Fraction(1, n)
        return Fraction(k, n) * sum(Fraction(1, j - 1) for j in range(k + 1, n + 1))

    def success_curve(self) -> List[Fraction]:
        return [self.success_probability(k) for k in range(self.n)]

    def optimal_cutoff(self) -> int:
        curve = self.success_curve()
        return max(range(self.n), key=lambda k: curve[k])

    def optimal_probability(self) -> Fraction:
        return self.success_probability(self.optimal_cutoff())

    def asymptotic_cutoff(self) -> float:
        return self.n / math.e

    @staticmethod
    def asymptotic_probability() -> float:
        return 1.0 / math.e

    def summary(self) -> Dict[str, float]:
        k = self.optimal_cutoff()
        return {
            "n": self.n,
            "optimal cutoff k*": k,
            "n / e": self.asymptotic_cutoff(),
            "P(success) at k*": float(self.success_probability(k)),
            "1 / e": self.asymptotic_probability(),
        }


@dataclass
class SecretarySimulationResult:
    n: int
    k: int
    num_trials: int
    success_rate: float
    std_error: float


class SecretarySimulator:
    """Monte Carlo simulation of the threshold rule on random permutations."""

    def __init__(self, n: int, seed: int = 42):
        self.n = int(n)
        self.rng = np.random.default_rng(seed)

    def run(self, k: int, num_trials: int = 100_000, batch: int = 20_000) -> SecretarySimulationResult:
        n = self.n
        if not (0 <= k < n):
            raise ValueError("need 0 <= k < n")
        successes = 0
        remaining = num_trials
        while remaining > 0:
            m = min(batch, remaining)
            remaining -= m
            vals = self.rng.random((m, n))  # larger value = better candidate
            best = vals.max(axis=1)
            if k == 0:
                successes += int((vals[:, 0] == best).sum())
                continue
            threshold = vals[:, :k].max(axis=1)
            beats = vals[:, k:] > threshold[:, None]
            hired_any = beats.any(axis=1)
            first = beats.argmax(axis=1) + k
            chosen = vals[np.arange(m), first]
            successes += int((hired_any & (chosen == best)).sum())
        rate = successes / num_trials
        return SecretarySimulationResult(
            n=n, k=k, num_trials=num_trials, success_rate=rate,
            std_error=math.sqrt(rate * (1 - rate) / num_trials),
        )
