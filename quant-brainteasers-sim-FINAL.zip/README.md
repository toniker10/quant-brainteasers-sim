# quant-brainteasers-sim

**Exact analytical solutions + large-scale Monte Carlo validation for six classic quant-interview probability brainteasers**, combining mathematical modeling, simulation, and data visualization in clean, tested, object-oriented Python.

[![CI](https://github.com/toniker10/quant-brainteasers-sim/actions/workflows/ci.yml/badge.svg)](https://github.com/toniker10/quant-brainteasers-sim/actions/workflows/ci.yml)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](pyproject.toml)
[![License: MIT](https://img.shields.io/badge/license-MIT-lightgrey)](LICENSE)

| Problem | Module | Headline Result |
|---|---|---|
| **The Coin Betting Dilemma** | [`src/betting_game.py`](src/betting_game.py) | EV-maximizing all-in strategy has expected wealth ≈ **4.07 × 10¹⁹** but a **~100% probability of ruin** |
| **The `[3, 4, 5]` Dice Sequence** | [`src/dice_sequence.py`](src/dice_sequence.py) | $P(\text{Odd}) = \dfrac{216}{431} \approx \mathbf{0.50116}$ |
| **Gambler's Ruin** | [`src/gamblers_ruin.py`](src/gamblers_ruin.py) | Even with a 55% edge, a $10 bankroll aiming for $20 busts **11.9%** of the time |
| **Secretary Problem** | [`src/secretary_problem.py`](src/secretary_problem.py) | Reject the first ~n/e candidates → hire the best with P → **1/e ≈ 0.368** |
| **Coupon Collector** | [`src/coupon_collector.py`](src/coupon_collector.py) | E[T] = n·Hₙ ≈ n ln n (n = 50 → **≈ 225** draws) |
| **Coin Patterns / Penney's Game** | [`src/coin_patterns.py`](src/coin_patterns.py) | E[HH] = 6 but E[HT] = 4; the second player always wins Penney's game (e.g. THH beats HHH **7/8**) |

---

## Table of Contents

1. [Project Overview & Motivation](#1-project-overview--motivation)
2. [Mathematical Derivations](#2-mathematical-derivations)
   - [2.1 The Coin Betting Dilemma](#21-the-coin-betting-dilemma)
   - [2.2 The `[3,4,5]` Dice Sequence](#22-the-3-4-5-dice-sequence)
  - [2.3 Gambler's Ruin](#23-gamblers-ruin)
  - [2.4 The Secretary Problem](#24-the-secretary-problem)
  - [2.5 The Coupon Collector](#25-the-coupon-collector)
  - [2.6 Coin Patterns & Penney's Game](#26-coin-patterns--penneys-game)
3. [Results: Theoretical vs. Monte Carlo](#3-results-theoretical-vs-monte-carlo)
4. [Visualizations](#4-visualizations)
5. [Key Insights](#5-key-insights)
6. [Repository Structure](#6-repository-structure)
7. [How to Run](#7-how-to-run)
8. [Testing & CI](#8-testing--ci)
9. [Requirements](#9-requirements)
10. [License](#10-license)

---

## 1. Project Overview & Motivation

Both problems are famous in quant-interview circles because the "obviously correct" answer — maximize expected value; guess $P(\text{Odd}) \approx 0.5$ by symmetry — is subtly wrong, and the reasons why are foundational to quantitative finance:

- **Problem 1** illustrates the gap between the **ensemble average** (what expected-value math says) and the **time average** (what actually happens to a single wealth path over time) — the central idea of *ergodicity economics* and the motivation for the **Kelly Criterion**. It's the same reasoning that explains why no rational trader sizes positions purely to maximize expected value without regard to variance and compounding.
- **Problem 2** demonstrates **absorbing Markov chains** and how a first-step / parity decomposition turns a combinatorially awkward question ("on which roll does a pattern first appear?") into a solvable linear system. It also shows why *self-overlapping* patterns require the same machinery used in the **Knuth-Morris-Pratt (KMP)** string-matching algorithm.

This repository implements both problems as clean, fully tested, object-oriented Python modules, validates every analytical result against large-scale Monte Carlo simulation, and visualizes the results in a runnable Jupyter notebook.

---

## 2. Mathematical Derivations

### 2.1 The Coin Betting Dilemma

**Setup.** Start with $W_0 = \$100$. Flip a fair coin $n = 100$ times. On each flip, wager $B \le W_t$ (current wealth). A win pays $2B$ profit (wealth becomes $W_t + 2B$); a loss costs $B$ (wealth becomes $W_t - B$).

**Single-flip expected value.**

$$
\mathbb{E}[\Delta W] = \tfrac{1}{2}(2B) + \tfrac{1}{2}(-B) = \tfrac{1}{2}B
$$

Strictly increasing in $B$ ⟹ the **EV-maximizing** fraction of wealth to bet every flip is $f^\* = 1.0$ (bet everything).

**Expected terminal wealth, all-in.** A single loss brings wealth to exactly $0$ (absorbing), so after $n$ flips:

$$
\mathbb{E}[W_n] = \left(\tfrac12\right)^n \big(W_0 \cdot 3^n\big) + \left(1-\left(\tfrac12\right)^n\right)\cdot 0 = W_0\left(\tfrac32\right)^n
$$

For $W_0=100,\ n=100$: $\mathbb{E}[W_{100}] \approx 4.0656\times10^{19}$.

**Probability of ruin.**

$$
P(\text{ruin}) = 1 - \left(\tfrac12\right)^{100} \approx 0.999999999999999999999999999999
$$

Practically certain bankruptcy despite an astronomically large expected value — the central paradox of the problem.

**Ergodicity / Kelly Criterion.** For a fixed-fraction strategy betting fraction $f$, the per-flip growth factor is $(1+2f)$ on a win, $(1-f)$ on a loss. The **ensemble average** growth factor:

$$
\mathbb{E}[\text{growth}] = \tfrac12(1+2f) + \tfrac12(1-f) = 1 + \tfrac12 f \quad \text{(maximized at } f=1\text{)}
$$

But wealth compounds *multiplicatively*, so what an investor actually experiences is the **geometric-mean (time-average) growth rate**:

$$
G(f) = \left[(1+2f)(1-f)\right]^{1/2}
$$

For a bet paying $b{:}1$ with win probability $p$ (here $b=2,\ p=q=0.5$), the **Kelly-optimal fraction** is:

$$
f^\*_{\text{Kelly}} = p - \frac{q}{b} = 0.5 - \frac{0.5}{2} = 0.25
$$

At $f=1$, $G(1)=0$ — the time-average growth rate of the "EV-maximizing" strategy is exactly **zero** (certain eventual ruin), while $f=0.25$ maximizes long-run compounded growth.

### 2.2 The `[3, 4, 5]` Dice Sequence

**Setup.** Roll a fair six-sided die repeatedly until $[3,4,5]$ appears in three consecutive rolls. Find $P(\text{Odd})$: the probability the sequence first completes on an odd-indexed roll.

**Markov chain.** Three transient states plus one absorbing state:

| State | Meaning |
|---|---|
| 0 | No progress |
| 1 | Last roll was `3` |
| 2 | Last two rolls were `3, 4` |
| 3 (absorbing) | `3, 4, 5` observed |

| From \ Roll | → State 0 | → State 1 | → State 2 | → State 3 |
|---|---|---|---|---|
| State 0 | 5/6 (not 3) | 1/6 (roll 3) | — | — |
| State 1 | 4/6 (not 3,4) | 1/6 (roll 3) | 1/6 (roll 4) | — |
| State 2 | 4/6 (not 3,5) | 1/6 (roll 3) | — | 1/6 (roll 5) |

**Parity linear system.** Let $p_i$ = probability of odd-roll completion starting fresh from state $i$. Each transition consumes exactly one roll (flips parity), giving $p_i = \sum_j T_{ij}(1-p_j) + a_i$. Clearing denominators:

$$
\begin{aligned}
11p_0 + p_1 &= 6\\
4p_0 + 7p_1 + p_2 &= 6\\
4p_0 + p_1 + 6p_2 &= 6
\end{aligned}
$$

Solved exactly via Gaussian elimination over rational numbers (`DiceSequenceAnalytics.solve_exact`):

$$
P(\text{Odd}) = p_0 = \frac{216}{431} \approx 0.50116009280742\ldots
$$

**Generalization.** For self-overlapping targets (e.g. `[6, 6]`), the naive "reset to state 0 or 1" logic above is *not* generally correct — the **KMP failure function** is needed to compute the correct fallback state when a roll breaks a partial match. `GeneralizedSequenceSolver` builds this automaton for any sequence and any number of die faces, then solves $(I + T)p = \text{rowsum}(T) + a$ via `numpy.linalg.solve`.

---

### 2.3 Gambler's Ruin

Bet $1 per round, win probability `p`, stop at `N` or `0`. With `r = q/p`:

- Fair coin: `P(win) = i/N`, `E[duration] = i(N−i)`.
- Biased coin: `P(win) = (1 − r^i)/(1 − r^N)`.
- Infinite-wealth opponent: `P(ruin) = (q/p)^i` if `p > 1/2`, else `1`.

### 2.4 The Secretary Problem

Reject the first `k` of `n` candidates, then take the first one better than all seen so far:
`P(k, n) = (k/n) · Σ_{j=k+1..n} 1/(j−1)`. The optimum is `k* ≈ n/e` with success probability `→ 1/e`. For `n = 100`: `k* = 37`, `P = 0.3710`.

### 2.5 The Coupon Collector

`T` is a sum of independent geometric waiting times, giving `E[T] = n·Hₙ` and `Var[T] = n²·Σ1/i² − n·Hₙ`. The exact distribution comes from inclusion–exclusion: `P(T ≤ t) = Σ_j (−1)^j C(n,j) (1 − j/n)^t`.

### 2.6 Coin Patterns & Penney's Game

Using Conway's correlation `X·Y = Σ_k [suffix_k(X) = prefix_k(Y)] · 2^(k−1)`: the expected waiting time for `A` is `2·(A·A)`, and `Odds(B beats A) = (A·A − A·B) : (B·B − B·A)`. This is the same self-overlap structure that separates `[3,4,5]` (E = 6³) from `[6,6]` (E = 6² + 6) in the dice module.

---

## 3. Results: Theoretical vs. Monte Carlo

*(Actual output from this codebase — see [`scripts/generate_readme_assets.py`](scripts/generate_readme_assets.py) and the notebook to reproduce.)*

### Coin Betting Dilemma (100,000 simulated players, 100 flips)

| Strategy | Analytical Mean | Simulated Mean | Simulated Median | P(Ruin) |
|---|---|---|---|---|
| **A: All-In** ($f=1.0$) | $\approx 4.07\times10^{19}$ | $\$0$ (dominated by float rounding of a $2^{-100}$-probability event) | $\$0$ | **100%** |
| **B: Kelly** ($f=0.25$) | grows at rate $G(0.25)$ | $\approx \$10{,}718{,}525$ | $\approx \$36{,}110$ | **0%** |
| **C: Fixed 10%** ($f=0.10$) | grows at rate $G(0.10)$ | $\approx \$13{,}170$ | $\approx \$4{,}690$ | **0%** |

> The all-in strategy's simulated mean rounds to \$0 across any *finite* sample of 100,000 players because the winning path has probability $2^{-100}\approx 8\times10^{-31}$ — you would need far more players than exist in the observable universe to expect to see it even once. The astronomical analytical EV is real, but is carried entirely by a practically unobservable event, which is exactly the point of the exercise.

### `[3, 4, 5]` Dice Sequence

| Quantity | Analytical (Exact) | Monte Carlo (500,000 trials) |
|---|---|---|
| $P(\text{Odd})$ | $216/431 \approx 0.5011601$ | $\approx 0.5022$ |
| Mean rolls to completion | $6^3 = 216$ | $\approx 216$ |

Run the notebook to regenerate this table with fresh random seeds / larger sample sizes.

---

### Additional problems (exact vs. Monte Carlo)

| Problem | Quantity | Exact | Monte Carlo |
| --- | --- | --- | --- |
| Gambler's ruin (start $10, target $20, p = 0.55) | P(win) | 0.88150 | ≈ 0.884 (50,000 trials) |
| Gambler's ruin (same) | E[duration] | 76.30 | ≈ 76.03 |
| Secretary (n = 100, k = 37) | P(hire best) | 0.37104 | ≈ 0.3696 (100,000 trials) |
| Coupon collector (n = 50) | E[T] / Var[T] | 224.96 / 3837.9 | ≈ 224.9 / 3817.6 (30,000 trials) |
| Coin patterns | E[HH], E[HT], E[HTH], E[HHH] | 6, 4, 10, 14 | ≈ 6.01, 4.00, 10.04, 14.03 |
| Penney's game | P(THH before HHH) | 7/8 = 0.875 | ≈ 0.874 (100,000 trials) |

---

## 4. Visualizations

**Wealth trajectories, log scale — All-In vs. Kelly fraction (80 sample paths each):**

![Wealth trajectories](assets/wealth_trajectories.png)

Nearly every all-in trajectory collapses to \$0 within the first few flips (a single loss is fatal), while Kelly-fraction trajectories show a wide spread of outcomes and consistent long-run growth.

**Ensemble average vs. time average growth rate:**

![Ergodicity growth](assets/ergodicity_growth.png)

The ensemble average (red) is maximized at $f=1$ — exactly why naive EV maximization says "bet everything." The time-average / geometric growth rate (blue) peaks at the Kelly fraction $f^\*=0.25$ and collapses to zero at $f=1$.

**Distribution of final wealth across strategies (20,000 players):**

![Final wealth distributions](assets/final_wealth_distributions.png)

**Monte Carlo convergence to the analytical dice-sequence answer:**

![Dice convergence](assets/dice_convergence.png)

**Distribution of rolls needed to complete `[3, 4, 5]`:**

![Dice rolls distribution](assets/dice_rolls_distribution.png)

**Gambler's ruin — probability of ruin vs. edge, for different bankrolls (dots = Monte Carlo):**

![Gambler's ruin](assets/gamblers_ruin.png)

A small edge helps far more when the bankroll is large; at p = 0.5 every bankroll has exactly a 50% chance of ruin when the target is double the start.

**Secretary problem — success probability vs. number of rejected candidates (n = 100):**

![Secretary curve](assets/secretary_curve.png)

The curve peaks at k* = 37 ≈ n/e with success probability 0.371, close to the 1/e limit.

**Coupon collector — simulated distribution and exact CDF (n = 50):**

![Coupon collector](assets/coupon_collector.png)

**Coin patterns and Penney's game — waiting times and head-to-head win probabilities:**

![Penney's game](assets/penney_game.png)

Same-length patterns have different waiting times (HHH: 14 flips, HHT: 8), and for every pattern Player 1 picks, Player 2 has a reply that wins more than 50% of the time.

---

## 5. Key Insights

- **Kelly Criterion.** Maximizing expected value and maximizing long-run growth rate are *different objectives* whenever wealth compounds multiplicatively. The Kelly fraction ($f^\*=0.25$ here) maximizes $\mathbb{E}[\log W_n]$ — equivalent to maximizing the *median* / almost-sure long-run growth of terminal wealth, not its mean.
- **Risk of Ruin & Ergodicity.** A strategy can have unbounded expected value and still be almost-surely catastrophic for any individual path — the practical argument against "bet the farm" position sizing in trading, regardless of how favorable the odds look in expectation.
- **Markov States & Absorption.** Pattern-matching problems ("when does event X first happen") are naturally modeled as absorbing Markov chains. The parity trick — tracking "P(absorbed on odd step)" as its own linear system — sidesteps summing an infinite series directly.
- **Self-Overlap Matters.** Naively assuming "a broken match always resets to state 0 (or state 1 if the new roll matches the first symbol)" is only valid for non-self-overlapping sequences like `[3,4,5]`. Sequences like `[6,6]` need the KMP failure function to compute fallback states correctly — otherwise the model silently gives a wrong answer.

---

## 6. Repository Structure

```
quant-brainteasers-sim/
├── README.md
├── LICENSE
├── pyproject.toml
├── requirements.txt
├── .gitignore
├── .github/
│   └── workflows/
│       └── ci.yml              # Runs the test suite on every push/PR
├── assets/                     # Generated charts embedded in this README
├── scripts/
│   ├── generate_readme_assets.py   # charts for modules 1-2
│   └── generate_new_assets.py      # charts for modules 3-6
├── src/
│   ├── __init__.py
│   ├── betting_game.py         # Problem 1: analytics, simulation, ergodicity
│   ├── dice_sequence.py        # Problem 2: analytics, generalized solver, Monte Carlo
│   ├── gamblers_ruin.py        # Problem 3: ruin probability & duration
│   ├── secretary_problem.py    # Problem 4: optimal stopping
│   ├── coupon_collector.py     # Problem 5: collection time distribution
│   └── coin_patterns.py        # Problem 6: waiting times & Penney's game
├── notebooks/
│   └── quant_analysis.ipynb    # Runs simulations & generates all charts interactively
└── tests/
    ├── test_betting.py
    ├── test_dice.py
    ├── test_gamblers_ruin.py
    ├── test_secretary.py
    ├── test_coupon.py
    └── test_coin_patterns.py
```

---

## 7. How to Run

### Installation

```bash
git clone <this-repo-url>
cd quant-brainteasers-sim
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Or, as an installable package (uses `pyproject.toml`):

```bash
pip install -e ".[dev]"
```

### Running the unit tests

```bash
pytest tests/ -v
```

### Regenerating the README charts (modules 3-6: `python scripts/generate_new_assets.py`)

```bash
python scripts/generate_readme_assets.py
```

### Running the full analysis notebook

```bash
jupyter notebook notebooks/quant_analysis.ipynb
```

### Quick start from Python

```python
from src.betting_game import BettingAnalytics, CoinBettingSimulator, default_strategies

analytics = BettingAnalytics(initial_wealth=100.0, num_flips=100)
print(analytics.summary())

sim = CoinBettingSimulator(initial_wealth=100.0, num_flips=100, seed=42)
results = sim.compare_strategies(default_strategies(), num_players=100_000)
for name, res in results.items():
    print(name, res.summary())
```

```python
from src.dice_sequence import DiceSequenceAnalytics, DiceSequenceSimulator, GeneralizedSequenceSolver

print(DiceSequenceAnalytics().summary())                       # exact 216/431
print(GeneralizedSequenceSolver([1, 2, 3, 4], num_faces=6).solve())  # any sequence

from src.gamblers_ruin import GamblersRuinAnalytics
from src.secretary_problem import SecretaryAnalytics
from src.coupon_collector import CouponCollectorAnalytics
from src.coin_patterns import PenneyAnalytics, expected_waiting_time

print(GamblersRuinAnalytics(10, 20, 0.55).summary())
print(SecretaryAnalytics(100).summary())                       # k* = 37, P = 0.371
print(CouponCollectorAnalytics(50).summary())
print(expected_waiting_time("HH"), expected_waiting_time("HT"))  # 6 vs 4
print(PenneyAnalytics.prob_b_first("HHH", "THH"))              # 7/8

sim = DiceSequenceSimulator(seed=42)
result = sim.run(sequence=[3, 4, 5], num_trials=1_000_000)      # ~7s, vectorized
print("Empirical P(Odd):", result.empirical_p_odd)
```

---

## 8. Testing & CI

- **89 unit tests** across all six modules (`tests/test_*.py`), covering analytical correctness, simulator invariants (e.g. wealth never negative, probabilities sum to 1), edge cases, and Monte Carlo convergence within tolerance.
- **Continuous Integration** via GitHub Actions ([`.github/workflows/ci.yml`](.github/workflows/ci.yml)) runs the full test suite on Python 3.10, 3.11, and 3.12 on every push and pull request.

```bash
pytest tests/ -v
# ============================== 89 passed ==============================
```

---

## 9. Requirements

See [`requirements.txt`](requirements.txt):

- `numpy`, `pandas` — numerical computation & data handling
- `matplotlib`, `plotly` — static and interactive visualization
- `scipy` — supplementary numerical routines
- `pytest` — unit testing
- `jupyter`, `nbformat` — running the analysis notebook

---

## 10. License

Released under the [MIT License](LICENSE) — an educational / portfolio project demonstrating quantitative modeling, simulation, and software engineering practices.
