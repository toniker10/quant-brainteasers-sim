"""Generate charts for modules 3-6 (gambler's ruin, secretary problem,
coupon collector, coin patterns) from the real analytics/simulation code.
Run from the repo root:  python scripts/generate_new_assets.py"""

import sys
sys.path.insert(0, ".")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from src.gamblers_ruin import GamblersRuinAnalytics, GamblersRuinSimulator
from src.secretary_problem import SecretaryAnalytics, SecretarySimulator
from src.coupon_collector import CouponCollectorAnalytics, CouponCollectorSimulator
from src.coin_patterns import PenneyAnalytics, CoinPatternSimulator, expected_waiting_time

plt.rcParams.update({
    "figure.dpi": 150, "savefig.dpi": 150, "font.size": 11, "axes.grid": True,
    "grid.alpha": 0.25, "axes.spines.top": False, "axes.spines.right": False,
    "figure.facecolor": "white", "axes.facecolor": "white",
})
RED, BLUE, TEAL, GRAY = "#d1495b", "#2e86ab", "#118a7e", "#6c757d"

# 1. Gambler's ruin: P(ruin) vs edge, for several bankrolls (target = 2 x start)
ps = np.linspace(0.40, 0.60, 41)
fig, ax = plt.subplots(figsize=(7.5, 4.5))
for start, c in [(5, RED), (10, BLUE), (25, TEAL)]:
    ruin = [float(GamblersRuinAnalytics(start, 2 * start, float(p)).ruin_probability()) for p in ps]
    ax.plot(ps, ruin, color=c, linewidth=2, label=f"${start} -> ${2 * start}")
for p in (0.45, 0.55):
    r = GamblersRuinSimulator(10, 20, p, seed=1).run(20_000)
    ax.scatter([p], [r.ruin_rate], color="black", zorder=5, s=25)
ax.scatter([], [], color="black", s=25, label="Monte Carlo ($10 -> $20)")
ax.axvline(0.5, color=GRAY, linestyle="--", linewidth=1)
ax.set_xlabel("Win probability p"); ax.set_ylabel("P(ruin)")
ax.set_title("Gambler's ruin: a bigger bankroll amplifies the edge", fontweight="bold")
ax.legend(); plt.savefig("assets/gamblers_ruin.png", bbox_inches="tight"); plt.close()

# 2. Secretary problem: P(success) vs cutoff k
n = 100
an = SecretaryAnalytics(n)
ks = np.arange(n)
curve = [float(x) for x in an.success_curve()]
kstar = an.optimal_cutoff()
fig, ax = plt.subplots(figsize=(7.5, 4.5))
ax.plot(ks, curve, color=BLUE, linewidth=2, label="Exact")
sim = SecretarySimulator(n, seed=3)
mc_k = [0, 10, 20, 30, kstar, 50, 60, 80, 95]
ax.scatter(mc_k, [sim.run(k, 40_000).success_rate for k in mc_k], color="black", s=25, zorder=5, label="Monte Carlo")
ax.axvline(kstar, color=RED, linestyle="--", label=f"k* = {kstar} (n/e = {n / np.e:.1f})")
ax.axhline(1 / np.e, color=GRAY, linestyle=":", label="1/e = 0.368")
ax.set_xlabel("Candidates rejected (k)"); ax.set_ylabel("P(hire the best)")
ax.set_title(f"Secretary problem, n = {n}", fontweight="bold"); ax.legend()
plt.savefig("assets/secretary_curve.png", bbox_inches="tight"); plt.close()

# 3. Coupon collector: simulated distribution vs exact CDF
n = 50
ca = CouponCollectorAnalytics(n)
res = CouponCollectorSimulator(n, seed=5).run(40_000)
fig, axes = plt.subplots(1, 2, figsize=(11, 4.3))
axes[0].hist(res.samples, bins=60, density=True, color=BLUE, alpha=0.75)
axes[0].axvline(float(ca.expected_draws()), color=RED, linestyle="--", label=f"E[T] = {float(ca.expected_draws()):.1f}")
axes[0].set_xlabel("Draws needed"); axes[0].set_ylabel("Density")
axes[0].set_title(f"Distribution of T (n = {n}, 40,000 trials)", fontweight="bold"); axes[0].legend()
ts = np.arange(n, 700, 5)
axes[1].plot(ts, [float(ca.cdf(int(t))) for t in ts], color=TEAL, linewidth=2, label="Exact CDF")
axes[1].plot(ts, [res.empirical_cdf(int(t)) for t in ts], color="black", linestyle=":", label="Empirical CDF")
axes[1].set_xlabel("t"); axes[1].set_ylabel("P(T <= t)")
axes[1].set_title("Exact vs. empirical CDF", fontweight="bold"); axes[1].legend()
plt.savefig("assets/coupon_collector.png", bbox_inches="tight"); plt.close()

# 4. Coin patterns: waiting times + Penney win matrix
pats = ["HHH", "HHT", "HTH", "HTT", "THH", "THT", "TTH", "TTT"]
fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), gridspec_kw={"width_ratios": [1, 1.3]})
wt = [expected_waiting_time(p) for p in pats]
sim = CoinPatternSimulator(seed=2)
mc = [sim.waiting_time(p, 30_000).mean_waiting_time for p in pats]
x = np.arange(len(pats))
axes[0].bar(x - 0.2, wt, 0.4, color=BLUE, label="Exact")
axes[0].bar(x + 0.2, mc, 0.4, color=GRAY, label="Monte Carlo")
axes[0].set_xticks(x); axes[0].set_xticklabels(pats, rotation=45)
axes[0].set_ylabel("Expected flips until pattern")
axes[0].set_title("Same length, different waiting times", fontweight="bold"); axes[0].legend()
M = np.full((8, 8), np.nan)
for i, a in enumerate(pats):
    for j, b in enumerate(pats):
        if a != b:
            M[i, j] = float(PenneyAnalytics.prob_b_first(a, b))
im = axes[1].imshow(M, cmap="RdBu_r", vmin=0, vmax=1)
axes[1].grid(False)
axes[1].set_xticks(range(8)); axes[1].set_xticklabels(pats, rotation=45)
axes[1].set_yticks(range(8)); axes[1].set_yticklabels(pats)
axes[1].set_xlabel("Player 2 (column) picks"); axes[1].set_ylabel("Player 1 (row) picks")
for i in range(8):
    for j in range(8):
        if not np.isnan(M[i, j]):
            axes[1].text(j, i, f"{M[i, j]:.2f}", ha="center", va="center", fontsize=8,
                         color="white" if abs(M[i, j] - 0.5) > 0.25 else "black")
axes[1].set_title("Penney's game: P(Player 2 wins)", fontweight="bold")
fig.colorbar(im, ax=axes[1], fraction=0.046)
plt.savefig("assets/penney_game.png", bbox_inches="tight"); plt.close()
print("done")
